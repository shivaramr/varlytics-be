from fastapi import FastAPI
from app.api import stock, search, varlytics_special, simulations, portfolio

app = FastAPI(
    title="VaRLytics API",
    openapi_tags=[
        {
            "name": "General",
            "description": "General utilities like search."
        },
        {
            "name": "Stock",
            "description": "Operations related to stock data."
        },
        {
            "name": "VarLytics Special",
            "description": "Specialized financial analytics and simulations."
        },
        {
            "name": "Simulations",
            "description": "22 different simulation models including GARCH, EGARCH, GJR-GARCH variants."
        },
        {
            "name": "Portfolio Analysis",
            "description": "Comprehensive portfolio risk analysis with multiple VaR models and stress testing."
        }
    ]
)

app.include_router(stock.router, prefix="/api")
app.include_router(search.router, prefix="/api")
app.include_router(varlytics_special.router, prefix="/api")
app.include_router(simulations.router, prefix="/api")
app.include_router(portfolio.router, prefix="/api")
