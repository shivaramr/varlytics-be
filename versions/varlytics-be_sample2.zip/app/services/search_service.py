import pandas as pd
import requests
from app.data.stock_data import FALLBACK_STOCKS, FALLBACK_INDICES, FALLBACK_ALL
from app.utils.index_utils import INDIAN_INDICES, is_index
from io import StringIO

# Cache for stock data
_stock_cache = None

def _load_stock_data():
    """Load and cache NSE and BSE stock data plus indices"""
    global _stock_cache
    
    if _stock_cache is not None:
        return _stock_cache
    
    stock_dict = {}
    
    # First, add all indices to the dictionary
    for key, info in FALLBACK_INDICES.items():
        stock_dict[key] = {
            "name": info["name"],
            "sub_symbol": info["sub_symbol"],
            "is_index": True,
            "exchange": info.get("exchange", "NSE")
        }
    
    # Try to fetch from NSE India equity list
    try:
        url = "https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            # Parse CSV data
            df = pd.read_csv(StringIO(response.text))
            
            # Add NSE stocks to dictionary
            for _, row in df.iterrows():
                symbol = str(row['SYMBOL']).strip()
                name = str(row['NAME OF COMPANY']).strip()
                # Store NSE stocks without sub-symbol
                key = f"{symbol}"
                if key not in stock_dict:
                    stock_dict[key] = {
                        "name": name,
                        "sub_symbol": None,
                        "is_index": False
                    }
            
            print(f"Loaded {len(stock_dict)} NSE stocks")
    except Exception as e:
        print(f"Failed to load from NSE: {str(e)}")
    
    # Try to fetch from BSE using IIFL Scripmaster CSV
    try:
        url = "http://content.indiainfoline.com/IIFLTT/Scripmaster.csv"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            # Parse CSV data
            df = pd.read_csv(StringIO(response.text))
            
            # Filter for BSE equity stocks (Exch='B', ExchType='C' for cash/equity, Series='EQ')
            # ExchType 'C' is for cash segment (equity)
            bse_equities = df[(df['Exch'] == 'B') & (df['ExchType'] == 'C') & (df['Series'] == 'EQ')]
            
            # Add BSE stocks to dictionary
            bse_count = 0
            for _, row in bse_equities.iterrows():
                # Use Scripcode as the main symbol (BSE stocks use numeric codes)
                scripcode = str(row['Scripcode']).strip()
                # Use Name as the sub-symbol (trading symbol)
                sub_symbol = str(row['Name']).strip()
                # Use FullName as the company name
                name = str(row['FullName']).strip()
                
                # Only add if not already present (NSE takes precedence)
                # This ensures we get BSE-only stocks
                key = scripcode
                if key not in stock_dict and scripcode and name:
                    stock_dict[key] = {
                        "name": name,
                        "sub_symbol": sub_symbol,
                        "is_index": False
                    }
                    bse_count += 1
            
            print(f"Loaded {bse_count} BSE-only stocks. Total stocks: {len(stock_dict)}")
    except Exception as e:
        print(f"Failed to load from BSE: {str(e)}")
    
    # If we got data from either source, cache and return it
    if stock_dict:
        _stock_cache = stock_dict
        return stock_dict
    
    # Fallback: Use a comprehensive list of major Indian stocks from both NSE and BSE plus indices
    fallback_with_indices = {}
    
    # Add indices first
    for key, info in FALLBACK_INDICES.items():
        fallback_with_indices[key] = {
            "name": info["name"],
            "sub_symbol": info["sub_symbol"],
            "is_index": True,
            "exchange": info.get("exchange", "NSE")
        }
    
    # Add stocks
    for key, info in FALLBACK_STOCKS.items():
        fallback_with_indices[key] = {
            "name": info["name"],
            "sub_symbol": info.get("sub_symbol"),
            "is_index": False
        }
    
    _stock_cache = fallback_with_indices
    return fallback_with_indices

def search_stocks(query: str):
    """
    Search for stocks and indices in NSE and BSE based on symbol or company name.
    Returns a list of matching stocks/indices with symbol, name, and sub_symbol (for BSE).
    """
    if not query:
        return []
    
    query = query.upper().strip()
    results = []
    
    try:
        # Load stock data
        stock_data = _load_stock_data()
        
        # Search through stocks
        for symbol, data in stock_data.items():
            if not symbol or not data:
                continue
            
            name = data.get("name", "")
            sub_symbol = data.get("sub_symbol")
            is_idx = data.get("is_index", False)
            
            if not name:
                continue
            
            # Search for query in symbol, sub-symbol, and name (case-insensitive)
            symbol_upper = symbol.upper()
            name_upper = name.upper()
            sub_symbol_upper = sub_symbol.upper() if sub_symbol else ""
            
            if query in symbol_upper or query in name_upper or (sub_symbol and query in sub_symbol_upper):
                result = {
                    "symbol": symbol,
                    "name": name.title() if not is_idx else name,
                    "is_index": is_idx
                }
                # Add sub_symbol only if it exists (for BSE stocks or indices)
                if sub_symbol:
                    result["sub_symbol"] = sub_symbol
                
                results.append(result)
        
        # Sort results: indices first, then exact matches, then by symbol length
        def sort_key(item):
            symbol = item["symbol"].upper()
            sub_symbol = item.get("sub_symbol", "").upper() if item.get("sub_symbol") else ""
            is_idx = item.get("is_index", False)
            
            # Prioritize indices
            if is_idx:
                # Exact match on index
                if symbol == query or sub_symbol == query:
                    return (0, 0, len(symbol), symbol)
                # Starts with query on index
                elif symbol.startswith(query) or sub_symbol.startswith(query):
                    return (0, 1, len(symbol), symbol)
                # Other index matches
                else:
                    return (0, 2, len(symbol), symbol)
            
            # Then stocks: exact matches first
            if symbol == query or sub_symbol == query:
                return (1, 0, len(symbol), symbol)
            # Then stocks that start with query
            elif symbol.startswith(query) or sub_symbol.startswith(query):
                return (1, 1, len(symbol), symbol)
            # Then by length and alphabetically
            else:
                return (1, 2, len(symbol), symbol)
        
        results.sort(key=sort_key)
        
        # Limit results to top 20 for better performance
        return results[:20]
        
    except Exception as e:
        print(f"Error searching stocks: {str(e)}")
        return []
