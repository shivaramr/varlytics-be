"""
Utility functions for generating chart data from simulation results.
"""
import numpy as np
import pandas as pd
import gzip
import base64
import json
import msgpack
import zstandard as zstd


def generate_chart_data(simulation_df: pd.DataFrame, num_bins: int = 30, sample_size: int = 50):
    """
    Generate chart data for visualization from simulation results.
    
    Args:
        simulation_df: DataFrame with shape (num_days, num_simulations) containing price paths
        num_bins: Number of bins for histogram
        sample_size: Number of sample paths to include in line chart
    
    Returns:
        Dictionary containing:
            - line_chart_data: List of dictionaries with x and y values for sample paths with 756 points
            - histogram_data: List of dictionaries with bin centers and counts for terminal prices with 30 bins
    """
    num_days, num_simulations = simulation_df.shape
    sample_size = min(sample_size, num_simulations)

    # Line chart (first N paths)
    sample_paths = simulation_df.iloc[:, :sample_size].copy()
    sample_paths.insert(0, "x", np.arange(1, num_days + 1))
    line_chart_data = sample_paths.rename(columns={i: f"y{i}" for i in range(sample_size)}).to_dict(orient="records")

    # Histogram (terminal prices)
    final_prices = simulation_df.iloc[-1].values
    counts, bin_edges = np.histogram(final_prices, bins=num_bins)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    histogram_data = pd.DataFrame({
        "bin": np.round(bin_centers, 2),
        "count": counts.astype(int)
    }).to_dict(orient="records")

    # This graph can be decompressed and decrypted on the frontend using the decodeCompressedChartData function
    return {
        "line_chart_data": line_chart_data,
        "histogram_data": histogram_data
    }


# def compress_chart_data(chart_data: dict) -> str:
#     json_bytes = json.dumps(chart_data).encode('utf-8')
#     compressed = gzip.compress(json_bytes)
#     encoded = base64.b64encode(compressed).decode('utf-8')
#     return encoded
# import { inflate } from 'pako';

# For the above
# function decodeCompressedChartData(compressedBase64: string) {
#     const binaryString = atob(compressedBase64); // base64 decode
#     const charData = binaryString.split('').map((x) => x.charCodeAt(0));
#     const binData = new Uint8Array(charData);
#     const decompressed = inflate(binData, { to: 'string' }); // gzip decompress
#     return JSON.parse(decompressed);
# }

def compress_chart_data(chart_data: dict) -> str:
    packed = msgpack.packb(chart_data)
    compressed = zstd.ZstdCompressor(level=22).compress(packed)
    encoded = base64.b64encode(compressed).decode('utf-8')
    return encoded

# For the above
# npm install zstd-codec @msgpack/msgpack

# // chartDataDecoder.js
# import { decode as msgpackDecode } from '@msgpack/msgpack';
# import { ZstdCodec } from 'zstd-codec';

# let zstdSimple = null;

# /**
#  * Call this once before using `decodeCompressedChartData`.
#  * It loads the Zstandard WebAssembly module asynchronously.
#  */
# export async function initializeChartDataDecoder() {
#     return new Promise((resolve) => {
#         ZstdCodec.run((zstd) => {
#             zstdSimple = new zstd.Simple();
#             resolve();
#         });
#     });
# }

# /**
#  * Decodes chart data that was compressed using:
#  * - MessagePack
#  * - Zstandard
#  * - Base64 encoding
#  *
#  * @param {string} base64String - The Base64-encoded compressed chart data
#  * @returns {any} - The original chart data object
#  */
# export function decodeCompressedChartData(base64String) {
#     if (!zstdSimple) {
#         throw new Error('Decoder not initialized. Call initializeChartDataDecoder() first.');
#     }

#     const binaryString = atob(base64String);
#     const uint8Data = Uint8Array.from(binaryString, (c) => c.charCodeAt(0));
#     const decompressed = zstdSimple.decompress(uint8Data);
#     return msgpackDecode(decompressed);
# }

# How to use above?
# import {
#     initializeChartDataDecoder,
#     decodeCompressedChartData
# } from './chartDataDecoder.js';

# async function main() {
#     await initializeChartDataDecoder(); // only once at startup

#     const decodedData = decodeCompressedChartData(base64CompressedChartData);
#     console.log(decodedData);
# }

# main();
