import pandas as pd
import requests
from app.data.stock_data import FALLBACK_STOCKS
from io import StringIO

# Cache for stock data
_stock_cache = None

def _load_stock_data():
    """Load and cache NSE and BSE stock data"""
    global _stock_cache
    
    if _stock_cache is not None:
        return _stock_cache
    
    stock_dict = {}
    
    # Try to fetch from NSE India equity list
    try:
        url = "https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            # Parse CSV data
            df = pd.read_csv(StringIO(response.text))
            
            # Add NSE stocks to dictionary
            for _, row in df.iterrows():
                symbol = str(row['SYMBOL']).strip()
                name = str(row['NAME OF COMPANY']).strip()
                # Store NSE stocks without sub-symbol
                key = f"{symbol}"
                if key not in stock_dict:
                    stock_dict[key] = {
                        "name": name,
                        "sub_symbol": None
                    }
            
            print(f"Loaded {len(stock_dict)} NSE stocks")
    except Exception as e:
        print(f"Failed to load from NSE: {str(e)}")
    
    # Try to fetch from BSE using IIFL Scripmaster CSV
    try:
        url = "http://content.indiainfoline.com/IIFLTT/Scripmaster.csv"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            # Parse CSV data
            df = pd.read_csv(StringIO(response.text))
            
            # Filter for BSE equity stocks (Exch='B', ExchType='C' for cash/equity, Series='EQ')
            # ExchType 'C' is for cash segment (equity)
            bse_equities = df[(df['Exch'] == 'B') & (df['ExchType'] == 'C') & (df['Series'] == 'EQ')]
            
            # Add BSE stocks to dictionary
            bse_count = 0
            for _, row in bse_equities.iterrows():
                # Use Scripcode as the main symbol (BSE stocks use numeric codes)
                scripcode = str(row['Scripcode']).strip()
                # Use Name as the sub-symbol (trading symbol)
                sub_symbol = str(row['Name']).strip()
                # Use FullName as the company name
                name = str(row['FullName']).strip()
                
                # Only add if not already present (NSE takes precedence)
                # This ensures we get BSE-only stocks
                key = scripcode
                if key not in stock_dict and scripcode and name:
                    stock_dict[key] = {
                        "name": name,
                        "sub_symbol": sub_symbol
                    }
                    bse_count += 1
            
            print(f"Loaded {bse_count} BSE-only stocks. Total stocks: {len(stock_dict)}")
    except Exception as e:
        print(f"Failed to load from BSE: {str(e)}")
    
    # If we got data from either source, cache and return it
    if stock_dict:
        _stock_cache = stock_dict
        return stock_dict
    
    # Fallback: Use a comprehensive list of major Indian stocks from both NSE and BSE
    _stock_cache = FALLBACK_STOCKS
    return FALLBACK_STOCKS

def search_stocks(query: str):
    """
    Search for stocks in NSE and BSE based on symbol or company name.
    Returns a list of matching stocks with symbol, name, and sub_symbol (for BSE).
    """
    if not query:
        return []
    
    query = query.upper().strip()
    results = []
    
    try:
        # Load stock data
        stock_data = _load_stock_data()
        
        # Search through stocks
        for symbol, data in stock_data.items():
            if not symbol or not data:
                continue
            
            name = data.get("name", "")
            sub_symbol = data.get("sub_symbol")
            
            if not name:
                continue
            
            # Search for query in symbol, sub-symbol, and name (case-insensitive)
            symbol_upper = symbol.upper()
            name_upper = name.upper()
            sub_symbol_upper = sub_symbol.upper() if sub_symbol else ""
            
            if query in symbol_upper or query in name_upper or (sub_symbol and query in sub_symbol_upper):
                result = {
                    "symbol": symbol,
                    "name": name.title()
                }
                # Add sub_symbol only if it exists (for BSE stocks)
                if sub_symbol:
                    result["sub_symbol"] = sub_symbol
                
                results.append(result)
        
        # Sort results: exact symbol matches first, then by symbol length, then alphabetically
        def sort_key(item):
            symbol = item["symbol"].upper()
            sub_symbol = item.get("sub_symbol", "").upper() if item.get("sub_symbol") else ""
            
            # Prioritize exact matches (either symbol or sub_symbol)
            if symbol == query or sub_symbol == query:
                return (0, len(symbol), symbol)
            # Then prioritize starts with query
            elif symbol.startswith(query) or sub_symbol.startswith(query):
                return (1, len(symbol), symbol)
            # Then by length and alphabetically
            else:
                return (2, len(symbol), symbol)
        
        results.sort(key=sort_key)
        
        # Limit results to top 20 for better performance
        return results[:20]
        
    except Exception as e:
        print(f"Error searching stocks: {str(e)}")
        return []
