pip install

venv\Scripts\activate

uvicorn app.main:app --reload

Access Swagger UI at:
http://127.0.0.1:8000/docs#/
